trajectories = []
#p1 =790 300 p2=360 470
N=5
print("\tself.nPoints=",N)
print("\tself.seq = ",N)
print("\tself.trajectories=[ #p1 =790 300 p2=360 470")
for i in range(0,15):
    trajectory = []
    for j in range(0,5):
        trajectory.append([780-j*50, 450-i*10])
    print("\t",trajectory,",#",i)
    trajectories.append(trajectory)
print("\t]")
